FloraNet es un Proyecto que la cual predice, teien un chatbot integrado para consultas, información de planta/huerto en tiempo real y además la automatización de la misma. 


![image](https://github.com/user-attachments/assets/64e84637-c3a8-42c8-90df-92a771b2610d)
Pägina principal


![image](https://github.com/user-attachments/assets/648c2c62-aaf1-47b4-ae31-86ce8b3357b5)
Inicio de sesión


![image](https://github.com/user-attachments/assets/0d14cc36-0e4f-4ec2-8e2d-1cf1a5d91995)
Registro de usuarios


![image](https://github.com/user-attachments/assets/baa24c45-e3aa-4f8a-b9e1-f8a652825f4c)
Página de inicio 


![image](https://github.com/user-attachments/assets/4a62b3f6-e65f-4ebe-81b0-0df8431140e8)

![image](https://github.com/user-attachments/assets/c59abb99-31b7-4529-b298-9a0651b4b76a)

predicción 



![image](https://github.com/user-attachments/assets/a8286ea8-2998-41c8-b5e6-c39ffc17881e)

![image](https://github.com/user-attachments/assets/128bcc3d-5968-4813-acf6-29da5d2dc0c2)
Chatbot


![image](https://github.com/user-attachments/assets/40738a32-18e2-48ed-a85d-a60ded6b982d)
Datos del cultivo


![image](https://github.com/user-attachments/assets/36100616-a2a1-4b0f-a701-bd9a3dacd11b)
Automatización 


![image](https://github.com/user-attachments/assets/19a074fa-27e6-45a9-964f-f583ad22bbab)
Sobre nosotros


